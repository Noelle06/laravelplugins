---
title: Monitoring the health of all backups
weight: 3
---
