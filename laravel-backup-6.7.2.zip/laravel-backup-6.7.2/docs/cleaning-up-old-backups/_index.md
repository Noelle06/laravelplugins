---
title: Cleaning up old backups
weight: 2
---
